"""
전투 시뮬레이션 로그 및 결과 데이터클래스.

simulate() 함수가 반환하는 SimResult와,
verbose=True 시 함께 채워지는 SimLog를 정의한다.

클래스 구성:
  HitEvent        — 단일 피격 이벤트 (시각, 피해량, 크리 여부 등)
  BurstLogEntry   — 버스트 단계 사용/풀버스트 시작·종료 이벤트
  BuffEntry       — 스냅샷에 기록된 활성 버프 1건
  BuffSnapshot    — 풀버스트 진입 시각의 전체 버프 상태 스냅샷
  ReloadLogEntry  — 재장전 시작/완료 이벤트
  AmmoLogEntry    — 탄환 수 변화 이벤트
  BossLogEntry    — 보스 패턴 시작·종료·표적 파괴 (verbose와 무관, SimResult에 직접)
  SimLog          — 위 이벤트들의 컨테이너 + 요약 출력 메서드
  CategoryStat    — 딜량·히트수 묶음 (DamageBreakdown 구성 요소)
  DamageBreakdown — 캐릭터 대미지 분석 결과 (유형별·버스트 구간별)
  SimResult       — 전체 시뮬 결과 (히트 목록, 딜 합산) + 분석 출력 메서드

분석 함수:
  analyze_damage(result, char_name) → DamageBreakdown
  analyze_team(result)              → list[DamageBreakdown]
  print_team_analysis(result, chars)
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field


# ── 공통 헬퍼 ─────────────────────────────────────────────────────────────

_NORMAL_ATK_TAGS = frozenset({
    "normal", "core", "full_charge_hit", "core+full_charge_hit",
})

def _is_normal(ev: "HitEvent") -> bool:
    """HitEvent가 일반공격 계열이면 True.

    기본 발사 루프(CharState)에서 생성된 히트를 판별한다.
    skill_name == "기본 공격", pellet:N / core:pellet:N 태그,
    normal / core / full_charge_hit / core+full_charge_hit 태그를 포함한다.
    스킬 대미지(burst_damage, dot_damage, bonus_damage 등)는 False.

    발사 루프가 만든 히트라도 **이름이 붙어 있으면 스킬로 본다** — 무기 변경 모드의
    사격이 스킬 대미지인 예외(나유타 `기억 연소`)가 그렇다. 이 히트는 발사 태그
    (`full_charge_hit` 등)를 그대로 달고 있어, 태그만 보면 평타로 새어 들어간다.
    """
    if ev.skill_name == "기본 공격":
        return True
    if ev.skill_name and ev.skill_name != "기본 공격" and ev.hit_tag in _NORMAL_ATK_TAGS:
        return False
    tag = ev.hit_tag
    if tag.startswith("pellet:") or tag.startswith("core:pellet:"):
        return True
    return tag in _NORMAL_ATK_TAGS


# ── HitEvent ──────────────────────────────────────────────────────────────

@dataclass
class HitEvent:
    """단일 피격 이벤트. simulate()가 생성하는 가장 기본 단위."""
    t: float          # 발생 시각 (초)
    caster: str       # 딜러 캐릭터명
    damage: int       # 최종 피해량 (방어력 계산 후 정수)
    is_crit: bool     # 크리티컬 여부
    hit_tag: str      # 피격 종류 식별자:
                      #   "normal"            — 일반 자동 발사
                      #   "core"              — 코어 명중
                      #   "full_charge_hit"   — 풀차지 명중 (SR/RL)
                      #   "core+full_charge_hit" — 코어+풀차지
                      #   "pellet:N"          — SG N번째 산탄
                      #   "normal_skill"      — 일반공격 공식 스킬
                      #   "bonus_damage"      — 버스트 스킬 추가 대미지
                      #   "burst_damage" 등   — 그 외 스킬 stat 이름
    skill_name: str = "기본 공격"  # 스킬명 (일반공격은 "기본 공격")
    # ── 쫄몹(보스 패턴 summon)이 살아 있을 때 딜을 나누는 칸. 쫄몹이 없으면 아무도 안 읽는다 ──
    rule: str = ""    # 이 히트를 낸 효과의 대상 문자열(`all_enemies` 등). "" = 조준(무기 사격)
    split: bool = False  # 분할 대미지 — 맞은 적 수로 나눈다
    to: tuple[str, ...] | None = None  # 대상이 이미 정해진 히트(지속 대미지 틱) — 효과가 붙은 적 id
    # ── 좌표 off 파츠 다중 타격(보스 패턴 parts 표적의 `reach`). 닿을 파츠가 없으면 0으로 남는다 ──
    reach: int = 0        # 이 발이 닿는 파츠 위치 단계의 상한 (boss_pattern.hit_reach). 0 = 추가 히트 없음
    part_damage: int = 0  # 같은 발이 파츠 하나에 넣는 대미지 — 코어 없이 파츠 대미지 ▲를 얹어 다시 산정
    part: str = ""        # 파츠에 들어간 추가 히트면 그 파츠 이름. 본체 히트는 ""
    # 저지원 쪽(interrupt 표적의 `reach`) — 단계 상한은 「파츠 포함」 전체기를 빼고 잰다. 딜은 총딜 밖
    interrupt_reach: int = 0   # 이 발이 닿는 저지원 위치 단계의 상한. 0 = 추가 히트 없음
    interrupt_damage: int = 0  # 같은 발이 저지원 하나에 넣는 대미지 — 코어·파츠 판정 없이 다시 산정
    aimed: str = ""       # 좌표 off — 이 발이 겨눠 따로 맞힌 표적. 다중 타격에서 빠진다(한 발에 한 번, boss_pattern §조준)
    # ── 표적에 떨어진 히트(좌표 모드의 착탄 · 좌표 off의 겨눈 발). 본체 히트는 "" ──
    target: str = ""      # 이 히트가 맞힌 표적 이름 (boss_pattern `hit_target`이 이름으로 찾는다)
    extra: bool = False   # 관통·폭발 원으로 따로 맞은 표적 — 그 발 자신이 떨어진 곳이 아니다(트리거·게이지 없음)


# ── SimLog 구성 엔트리들 ──────────────────────────────────────────────────

@dataclass
class BurstLogEntry:
    """버스트 흐름에서 발생한 단일 이벤트."""
    t: float    # 발생 시각 (초)
    event: str  # 이벤트 종류:
                #   "stage:N 사용"    — N단계 버스트 스킬 사용
                #   "reenter:N 사용"  — N단계 reenter 재사용
                #   "full_burst 시작" — 풀버스트 진입
                #   "full_burst 종료" — 풀버스트 종료
    caster: str # 스킬 사용자 캐릭터명 ("full_burst 시작/종료"는 빈 문자열)


@dataclass
class BuffEntry:
    """BuffSnapshot에 기록된 활성 버프 1건."""
    name: str           # 버프 이름 (parsed_skills의 effect.name)
    caster: str         # 버프를 건 캐릭터명
    expires_at: float   # 만료 시각 (초). math.inf = 영구 지속


@dataclass
class BuffSnapshot:
    """풀버스트 진입 시각에 찍은 스쿼드 전체 버프 상태 스냅샷.

    BurstController가 "full_burst 시작" 이벤트 발생 시 생성한다.
    """
    t: float                              # 스냅샷 시각 (초)
    buffs_by_char: dict[str, list[BuffEntry]]  # 캐릭터명 → 해당 캐릭터에 적용된 버프 목록


@dataclass
class BuffEvent:
    """버프 1건의 활성/갱신/만료 이벤트."""
    t: float            # 발생 시각 (초)
    kind: str           # "activate" | "expire"
    name: str           # 버프 이름
    caster: str         # 버프를 건 캐릭터명
    target: str         # 버프를 받은 캐릭터명
    expires_at: float   # 활성화 시 예정 만료 시각 (expire 이벤트에서는 실제 만료 시각)
    value: float | None = None  # 버프 수치 (스킬 레벨 기준); expire 이벤트는 None
    stat: str | None = None     # 버프 stat 종류 (e.g. "atk_pct", "charge_speed_pct")


@dataclass
class InstantEvent:
    """인스턴트 효과 발동 이벤트."""
    t: float            # 발생 시각 (초)
    name: str           # 효과 이름
    caster: str         # 시전자
    target: str         # 대상 캐릭터명
    stat: str           # stat 종류 (e.g. "ammo_charge_pct")
    value: float | None # 수치


@dataclass
class ReloadLogEntry:
    """재장전 시작 또는 완료 이벤트."""
    t: float      # 발생 시각 (초)
    caster: str   # 재장전 캐릭터명
    event: str    # "재장전 시작" 또는 "재장전 완료"


@dataclass
class AmmoLogEntry:
    """탄환 수 변화 이벤트."""
    t: float    # 발생 시각 (초)
    caster: str # 캐릭터명
    ammo: int   # 변화 후 남은 탄환 수


@dataclass
class GaugeLogEntry:
    """버스트 게이지 가산 1건. `burst_gauge_mode`와 무관하게 언제나 기록된다.

    사이클이 왜 밀렸는지는 "누가 얼마를 넣었나"를 봐야만 알 수 있다 —
    게이지 모델의 디버그는 전적으로 이 로그에 의존한다.
    """
    t: float       # 발생 시각 (초)
    caster: str    # 게이지를 만든 캐릭터명
    source: str    # 출처: "weapon" / "weapon:full_charge" / "skill:스킬명" / "charge_pct:스킬명"
    amount: float  # 이번에 실제로 들어간 양(%). 상한에 걸려 잘린 뒤의 값
    gauge: float   # 가산 후 게이지(%)


@dataclass
class ControlLogEntry:
    """조작 구간 하나. 정본: docs/CONTROL.md §두 관점.

    **조작자 관점을 여기서 유도한다.** 컨트롤은 니케마다 따로 입력되지만 실제 조작은 카메라가
    한 명씩 옮겨 다니며 하므로, "같은 시각에 몇 명을 조작하고 있나"를 보려면 구간이 필요하다.
    실행층이 이미 구간을 만들고 있어 새 입력 형식 없이 기록만 하면 된다.

    연속된 같은 행위는 **한 구간으로 합친다** — 톡톡이를 발마다 적으면 로그가 폭발한다.
    """
    t0: float        # 시작 시각 (초)
    t1: float        # 종료 시각 (초). 전투가 끝날 때까지 열려 있었으면 시뮬 길이
    caster: str      # 조작 대상 캐릭터명
    input: str       # 원시 입력: "click" | "cover"
    mode: str        # click: "tap"·"hold" / cover: "cover"
    producer: str    # 이 구간을 연 것: 클릭 창 이름 · 엄폐 라벨(정책/시퀀스)


@dataclass
class BossLogEntry:
    """보스 패턴 전이 1건. `calculator/boss_pattern.py`가 쓴다.

    **verbose와 무관하게 채운다.** 「전투가 어떻게 흘렀나」가 아니라 「준 스크립트가 실제로
    돌기는 했나」의 답이라서다 — 패턴 하나가 조건을 못 만나 통째로 무발동이어도 딜은
    그럴듯하게 나온다.
    """
    t: float        # 발생 시각 (초)
    pattern: str    # 패턴 id
    kind: str       # 패턴 종류 (idle · interrupt · shield …)
    event: str      # "start" | "end" | "destroy"(표적 파괴 · 쫄몹 처치/자폭) | "down"(전투불능) | "revive"(부활) | "cover_break"
                    # | "debuff"(debuff 패턴 한 발의 부여 결과) | "dispel"(니케가 보스 버프를 해제)
    outcome: str = ""  # end만: "cleared" | "expired" | "followed" | "end"
    detail: str = ""   # 사람용 한 줄 (연 조건 · 파괴 표적 · 막은 딜)


@dataclass
class SquadHitEntry:
    """보스 공격 한 발(또는 보스 지속 피해 한 틱)이 니케 한 명에게 들어간 결과. verbose와 무관하게
    채운다(보스 로그와 같은 이유).

    층별로 **받은 양**을 따로 적는다 — 관통은 여러 층이 같은 피해를 각각 받고, 비관통은 맨 앞
    한 층만 받는다. 넷이 다 0이면 무적이었다. 지속 피해 틱은 체력만 받는다.
    """
    t: float
    pattern: str
    target: str
    damage: float          # 산정된 한 발 피해 (층에 나뉘기 전)
    pierce: bool
    decoy: float = 0.0     # 분신이 받은 양 (가장 바깥 층 — 받으면 아래 층은 전부 0이다)
    shield: float = 0.0    # 보호막이 받은 양
    cover: float = 0.0     # 엄폐물이 받은 양
    hp: float = 0.0        # 니케 체력이 받은 양
    hp_after: float = 0.0
    down: bool = False     # 이 발로 전투불능
    source: str = ""       # "" = 공격 발 · 지속 피해 틱이면 그 디버프 이름
    by: str = ""           # 쫄몹이 쏜 발이면 그 쫄몹 이름 (보스는 "")


# ── SimLog ────────────────────────────────────────────────────────────────

@dataclass
class SimLog:
    """verbose=True 시뮬 시 채워지는 전투 이벤트 로그 컨테이너.

    simulate()에서 SimResult.log 필드로 반환된다.
    verbose=False이면 SimResult.log는 None.
    """
    burst_log: list[BurstLogEntry] = field(default_factory=list)
    # 버스트 단계 사용, 풀버스트 시작/종료 이벤트 시간순 목록

    buff_snapshots: list[BuffSnapshot] = field(default_factory=list)
    # 풀버스트 진입마다 찍힌 버프 스냅샷 목록 (풀버스트 횟수만큼 쌓임)

    buff_events: list[BuffEvent] = field(default_factory=list)
    # 버프 활성/만료 이벤트 전체 목록 — 전투 전 구간 버프 타임라인 재구성용

    instant_events: list[InstantEvent] = field(default_factory=list)
    # 인스턴트 효과 발동 이벤트 목록

    reload_log: list[ReloadLogEntry] = field(default_factory=list)
    # 전 캐릭터의 재장전 시작/완료 이벤트 시간순 목록

    ammo_log: list[AmmoLogEntry] = field(default_factory=list)
    # 탄환 수 변화 이벤트 목록 (발사·재장전 완료·탄환 충전)

    gauge_log: list[GaugeLogEntry] = field(default_factory=list)
    # 버스트 게이지 가산 내역. 충전 창(풀버스트 종료 → 1단계 진입) 안에서만 쌓인다

    control_log: list[ControlLogEntry] = field(default_factory=list)
    # 조작 구간 목록 (click·cover). 조작자 관점·점유 검사의 유일한 원본이다

    control_preempt: dict = field(default_factory=dict)
    # 이름 → 조작을 뺏긴 횟수 (`control_mode="solo"`의 등급 조율 — 급한 요청에 카메라를 넘긴 횟수)

    def control_occupancy(self) -> dict:
        """조작 구간이 서로 얼마나 겹치는가. 정본: docs/CONTROL.md §조작자는 한 명.

        **카메라는 하나뿐**이므로 겹친 구간은 그만큼 비현실적인 상한이다. 반환:

            {"max": 최대 동시 조작 인원, "overlap_t": 2명 이상인 총 시간(초),
             "pairs": {(A, B): 겹친 시간}, "by_char": {이름: 조작한 총 시간}}

        경계에서 여는 쪽과 닫는 쪽이 같은 시각이면 겹침으로 세지 않는다(반열린 구간).
        """
        evs: list[tuple[float, int, str]] = []
        by_char: dict[str, float] = defaultdict(float)
        for e in self.control_log:
            if e.t1 <= e.t0:
                continue
            by_char[e.caster] += e.t1 - e.t0
            if e.input == "cover_all":
                continue   # 버튼 하나로 전원 — 카메라를 나눠 갖는 게 아니다
            evs.append((e.t0, 1, e.caster))
            evs.append((e.t1, -1, e.caster))
        if not evs:
            # 전체 엄폐만 있는 경우 — 조작 시간은 있지만 카메라를 나눠 갖지는 않는다
            return {"max": 0, "overlap_t": 0.0, "pairs": {}, "by_char": dict(by_char)}
        evs.sort(key=lambda x: (x[0], x[1]))   # 같은 시각이면 닫기(-1)를 먼저
        live: dict[str, int] = defaultdict(int)
        pairs: dict[tuple[str, str], float] = defaultdict(float)
        mx, overlap_t, prev = 0, 0.0, evs[0][0]
        for t, d, name in evs:
            span = t - prev
            if span > 0:
                who = sorted(n for n, c in live.items() if c > 0)
                if len(who) >= 2:
                    overlap_t += span
                    for i, a in enumerate(who):
                        for b in who[i + 1:]:
                            pairs[(a, b)] += span
            live[name] += d
            mx = max(mx, sum(1 for c in live.values() if c > 0))
            prev = t
        return {"max": mx, "overlap_t": overlap_t,
                "pairs": dict(pairs), "by_char": dict(by_char)}

    def control_summary(self) -> str:
        """조작자 관점 한 줄 — 몇 명을 동시에 조작하고 있었나."""
        occ = self.control_occupancy()
        if not occ["by_char"]:
            return "조작 없음 (자동)"
        who = " · ".join(f"{n} {v:.1f}s" for n, v in
                         sorted(occ["by_char"].items(), key=lambda kv: -kv[1]))
        line = f"조작 구간: {who}"
        if self.control_preempt:
            line += ("  · 선점 " + " · ".join(f"{n} {c}회" for n, c in
                                             sorted(self.control_preempt.items())))
        if occ["max"] >= 2:
            line += (f"  [동시 조작 최대 {occ['max']}명 · 겹침 {occ['overlap_t']:.1f}s"
                     f" — 비현실적 상한]")
        return line

    def burst_summary(self, chars: list[str] | None = None) -> str:
        """버스트 흐름 전체를 시간순으로 출력한다.

        chars 지정 시 해당 캐릭터가 사용자인 이벤트만 표시.
        full_burst 시작/종료처럼 caster가 없는 이벤트는 항상 포함.
        """
        lines = ["[버스트 사이클]"]
        for e in self.burst_log:
            if chars and e.caster and e.caster not in chars:
                continue
            caster_str = f"  {e.caster}" if e.caster else ""
            lines.append(f"  t={e.t:7.3f}s  {e.event}{caster_str}")
        return "\n".join(lines)

    def gauge_summary(self, top: int = 0) -> str:
        """버스트 게이지 충전 내역을 사이클별로 묶어 출력한다.

        `top`을 주면 사이클마다 기여 상위 몇 명까지만 적는다(0 = 전원).
        """
        lines = ["[버스트 게이지 충전]"]
        cycle: list[GaugeLogEntry] = []

        def flush() -> None:
            if not cycle:
                return
            by_src: dict[tuple[str, str], float] = {}
            for e in cycle:
                by_src[(e.caster, e.source)] = by_src.get((e.caster, e.source), 0.0) + e.amount
            rows = sorted(by_src.items(), key=lambda kv: -kv[1])
            if top:
                rows = rows[:top]
            lines.append(f"  t={cycle[0].t:7.3f}s → {cycle[-1].t:7.3f}s"
                         f"  ({cycle[-1].t - cycle[0].t:5.2f}초, {cycle[-1].gauge:6.2f}%)")
            for (caster, source), amt in rows:
                lines.append(f"      {amt:7.2f}%  {caster}  [{source}]")

        prev = 0.0
        for e in self.gauge_log:
            if e.gauge < prev - 1e-9:   # 게이지가 줄었다 = 1단계가 소모했다 = 새 사이클
                flush()
                cycle = []
            cycle.append(e)
            prev = e.gauge
        flush()
        return "\n".join(lines)

    def buff_summary(self, chars: list[str] | None = None) -> str:
        """풀버스트 진입마다 찍힌 버프 스냅샷을 출력한다.

        각 스냅샷은 해당 시각에 활성화된 버프 목록을 캐릭터별로 보여준다.
        chars 지정 시 해당 캐릭터의 버프만 표시.
        """
        lines = ["[버프 스냅샷 — 풀버스트 진입 시]"]
        for snap in self.buff_snapshots:
            lines.append(f"\n  ── t={snap.t:.3f}s ──")
            for char, buffs in snap.buffs_by_char.items():
                if chars and char not in chars:
                    continue
                if not buffs:
                    continue
                lines.append(f"  {char}:")
                for b in buffs:
                    exp = "영구" if b.expires_at == math.inf else f"{b.expires_at:.2f}s까지"
                    lines.append(f"    [{b.name}] by {b.caster}  ({exp})")
        return "\n".join(lines)


# ── SimResult ─────────────────────────────────────────────────────────────

@dataclass
class SimResult:
    """simulate() 반환값. 히트 목록과 딜 합산, 분석 출력 메서드를 포함한다."""
    hits: list[HitEvent] = field(default_factory=list)
    # 전투 중 발생한 모든 HitEvent. simulate() 종료 시 시각순 정렬.

    char_total: dict[str, int] = field(default_factory=dict)
    # 캐릭터명 → 전투 전체 누적 피해량

    squad_total: int = 0
    # 스쿼드 전체 누적 피해량 (char_total 합산)

    duration: float = 0.0
    # 시뮬레이션 지속 시간 (초)

    log: SimLog | None = None
    # verbose=True 시 채워지는 전투 이벤트 로그. False이면 None.

    # ── 보스 패턴 (enemy["patterns"]). 패턴이 없으면 비어 있다. verbose와 무관하다 ──
    boss_log: list[BossLogEntry] = field(default_factory=list)
    # 패턴 시작·종료·표적 파괴의 시간순 목록

    boss_score: int = 0
    # 표적 파괴 점수 합. 시뮬이 때려서 나온 값이 아니라 출처가 달라 **squad_total에 없다**

    boss_unmodeled: list[str] = field(default_factory=list)
    # 구간은 차지했지만 효과 모델이 없어 아무 일도 안 한 예약 패턴 id (지금은 예약 종류가 없다)

    squad_hits: list[SquadHitEntry] = field(default_factory=list)
    # 보스 공격이 니케에게 들어간 발 단위 기록 (attack 패턴이 있을 때만)

    add_char_total: dict[str, int] = field(default_factory=dict)
    # 캐릭터명 → 쫄몹(summon)에 들어간 딜. **char_total·squad_total에 없다** — 레이드 점수는 보스 딜이다

    add_total: int = 0
    # 쫄몹에 들어간 딜 합 (쫄몹 체력을 넘친 몫은 빠진다)

    add_overkill: int = 0
    # 쫄몹 체력을 넘친 딜 · 이미 사라진 쫄몹에 간 딜 — 아무 데도 안 들어가고 버려진다

    # ── 저지원 히트 — 저지원에 떨어지거나(겨눈 발 · 좌표 모드 착탄) reach로 닿았을 때만 채운다 ──
    interrupt_char_total: dict[str, int] = field(default_factory=dict)
    # 캐릭터명 → 저지원에 들어간 딜. **char_total·squad_total에 없다**(유저 결정 2026-09-18 · 2026-09-19) — 저지원을
    # 겨누는 만큼 점수를 잃는다. 파츠에 들어간 딜은 총딜에 있다

    interrupt_total: int = 0

    aim_log: list[tuple[float, str, str]] = field(default_factory=list)
    # (시각, 니케, 겨눈 곳) — 겨눈 곳이 바뀔 때만. "" = 본체(자동 에임) · 적 id 접두사(`__enemy__:`) = 쫄몹

    def aim_spans(self) -> dict[str, list[tuple[str, float]]]:
        """패턴 모드 — 니케마다 표적·쫄몹을 겨눈 시간(초)의 합. 본체("")는 뺀다. `aim_log`를 구간으로 접는다."""
        by: dict[str, list[tuple[float, str]]] = {}
        for t, name, target in sorted(self.aim_log):
            by.setdefault(name, []).append((t, "쫄몹" if target.startswith("__enemy__:") else target))
        out: dict[str, list[tuple[str, float]]] = {}
        for name, rows in by.items():
            acc: dict[str, float] = {}
            for (t0, target), (t1, _) in zip(rows, rows[1:] + [(self.duration, "")]):
                if target:
                    acc[target] = acc.get(target, 0.0) + max(0.0, t1 - t0)
            if acc:
                out[name] = sorted(acc.items(), key=lambda kv: -kv[1])
        return out

    def boss_summary(self) -> str:
        """보스 패턴이 실제로 어떻게 흘렀는지 시간순으로 적는다."""
        if not self.boss_log:
            return "[보스 패턴] 없음"
        lines = ["[보스 패턴]"]
        for e in self.boss_log:
            head = {"start": "시작", "end": "종료", "destroy": "파괴",
                    "down": "전투불능", "revive": "부활", "cover_break": "엄폐물 파괴",
                    "debuff": "디버프", "dispel": "해제됨"}.get(e.event, e.event)
            if e.event == "destroy" and e.kind == "summon":
                head = "쫄몹"      # 상세가 「랩쳐#1 처치」·「자폭」이다
            if e.outcome:
                head += f"({e.outcome})"
            tail = f"  {e.detail}" if e.detail else ""
            lines.append(f"  t={e.t:7.3f}s  {e.pattern} [{e.kind}] {head}{tail}")
        if self.boss_score:
            lines.append(f"  파괴 점수 {self.boss_score:,} (총딜에 미포함)")
        if self.boss_unmodeled:
            lines.append(f"  ⚠ 효과 모델 없음(구간만 차지): {' · '.join(self.boss_unmodeled)}")
        extra = [h for h in self.hits if h.part]
        if extra:
            by: dict[str, int] = {}
            for h in extra:
                by[h.caster] = by.get(h.caster, 0) + h.damage
            lines.append(f"  [파츠 다중 타격] {len(extra)}발 · 추가 딜 {sum(by.values()):,} (총딜에 포함)")
            for name, dmg in sorted(by.items(), key=lambda x: -x[1]):
                lines.append(f"    {name}: {dmg:,}")
        area = [h for h in self.hits if h.target and h.extra]
        if area:
            lines.append(f"  [관통·폭발로 따로 맞은 파츠] 딜 {sum(h.damage for h in area):,} (총딜에 포함)")
        landed = [h for h in self.hits if h.target and not h.extra]
        if landed:
            lines.append(f"  [파츠에 떨어진 탄] 딜 {sum(h.damage for h in landed):,} (총딜에 포함)")
        if self.interrupt_total:
            lines.append(f"  [저지원에 들어간 딜] {self.interrupt_total:,} (총딜에 미포함)")
            for name, dmg in sorted(self.interrupt_char_total.items(), key=lambda x: -x[1]):
                if dmg:
                    lines.append(f"    {name}: {dmg:,}")
        if self.aim_log:
            spans = self.aim_spans()
            if spans:
                lines.append("  [에임] 표적·쫄몹을 겨눈 시간 (본체는 빼고)")
                for name, rows in spans.items():
                    lines.append(f"    {name}: " + " · ".join(f"{tg} {sec:.1f}s" for tg, sec in rows))
        if self.add_total or self.add_overkill:
            lines.append(f"  [쫄몹에 들어간 딜] {self.add_total:,} (총딜에 미포함) · 넘치거나 빗나간 딜 "
                         f"{self.add_overkill:,}")
            for name, dmg in sorted(self.add_char_total.items(), key=lambda x: -x[1]):
                if dmg:
                    lines.append(f"    {name}: {dmg:,}")
            lines.append("  ⚠ 쫄몹은 좌표가 없다: 쫄몹을 겨눈 니케의 조준 딜이 먼저 나온 산 쫄몹에 통째로 · "
                         "보스 기준으로 산정한 딜")
        hits = [h for h in self.squad_hits if not h.source]
        if hits:
            taken: dict[str, list[float]] = {}
            for h in hits:
                row = taken.setdefault(h.target, [0, 0.0, 0.0, 0.0, 0.0])
                row[0] += 1
                row[1] += h.decoy
                row[2] += h.shield
                row[3] += h.cover
                row[4] += h.hp
            lines.append("  [피격] 발 · 분신 · 보호막 · 엄폐물 · 체력")
            for name, (n, dc, sh, cv, hp) in taken.items():
                lines.append(f"    {name}: {n}발 · {round(dc):,} · {round(sh):,} · "
                             f"{round(cv):,} · {round(hp):,}")
        ticks = [h for h in self.squad_hits if h.source]
        if ticks:
            dot: dict[str, list[float]] = {}
            for h in ticks:
                row = dot.setdefault(h.target, [0, 0.0])
                row[0] += 1
                row[1] += h.hp
            lines.append("  [지속 피해] 틱 · 체력")
            for name, (n, hp) in dot.items():
                lines.append(f"    {name}: {n}틱 · {round(hp):,}")
        return "\n".join(lines)

    def summary(self, chars: list[str] | None = None) -> str:
        """스쿼드 총 딜과 캐릭터별 딜량·비율을 출력한다.

        chars 지정 시 해당 캐릭터만 표시 (스쿼드 총 딜 기준 비율은 유지).
        딜량 내림차순 정렬.
        """
        lines = [
            f"시뮬레이션 {self.duration:.1f}초  "
            f"스쿼드 총 딜: {self.squad_total:,}"
        ]
        for name, dmg in sorted(self.char_total.items(), key=lambda x: -x[1]):
            if chars and name not in chars:
                continue
            pct = dmg / self.squad_total * 100 if self.squad_total else 0
            lines.append(f"  {name}: {dmg:,} ({pct:.1f}%)")
        return "\n".join(lines)

    def dmg_breakdown(self, chars: list[str] | None = None) -> str:
        """캐릭터별 기본공격/스킬 딜 비율을 한 줄 요약으로 출력한다.

        chars 지정 시 해당 캐릭터만 표시. 딜량 내림차순 정렬.
        스킬별 세부 내역이 필요하면 skill_breakdown_by_cycle() 사용.
        """
        lines = [f"{'캐릭터':<28} {'캐릭터 딜':>14} {'기본공격':>9} {'스킬':>9}"]
        lines.append("-" * 64)
        for name, total in sorted(self.char_total.items(), key=lambda x: -x[1]):
            if chars and name not in chars:
                continue
            normal = sum(e.damage for e in self.hits if e.caster == name and _is_normal(e))
            skill  = sum(e.damage for e in self.hits if e.caster == name and not _is_normal(e))
            n_pct = normal / total * 100 if total else 0
            s_pct = skill  / total * 100 if total else 0
            lines.append(f"{name:<28} {total:>14,} {n_pct:>8.1f}% {s_pct:>8.1f}%")
        return "\n".join(lines)

    def skill_breakdown_by_cycle(self, chars: list[str] | None = None) -> str:
        """버스트 사이클별 스킬 딜량·히트수를 집계해 출력한다.

        사이클 구분:
          사이클 0 — 전투 시작 ~ 첫 풀버스트 직전
          사이클 N — N번째 풀버스트 시작 ~ 다음 풀버스트 직전 (마지막은 전투 종료까지)

        verbose=False(log=None)이면 버스트 경계 정보가 없으므로
        전체 전투를 사이클 0 단일 구간으로 집계한다.

        chars 지정 시 해당 캐릭터만 표시. 각 캐릭터 내 스킬은 딜량 내림차순.
        """
        def skill_key(ev: HitEvent) -> str:
            return "일반공격" if _is_normal(ev) else ev.skill_name

        # 풀버스트 시작 시각으로 사이클 경계 수집
        burst_starts: list[float] = []
        if self.log:
            burst_starts = [e.t for e in self.log.burst_log if e.event == "full_burst 시작"]

        # 구간 정의: (label, t_start, t_end)
        boundaries: list[tuple[str, float, float]] = []
        all_bounds = [0.0] + burst_starts + [math.inf]
        for i in range(len(all_bounds) - 1):
            t0, t1 = all_bounds[i], all_bounds[i + 1]
            label = f"사이클 {i}  (t={t0:.3f}s" + (f" ~ {t1:.3f}s)" if t1 != math.inf else " ~ 종료)")
            boundaries.append((label, t0, t1))

        # 출력 대상 캐릭터 목록 (딜 내림차순)
        target_chars = [
            name for name, _ in sorted(self.char_total.items(), key=lambda x: -x[1])
            if not chars or name in chars
        ]

        lines = ["[버스트 사이클별 스킬 딜 집계]"]

        for label, t0, t1 in boundaries:
            cycle_hits = [e for e in self.hits if t0 <= e.t < t1]
            if not cycle_hits:
                continue

            lines.append(f"\n── {label} ──")

            for name in target_chars:
                char_hits = [e for e in cycle_hits if e.caster == name]
                if not char_hits:
                    continue

                dmg_by_skill: dict[str, int] = {}
                cnt_by_skill: dict[str, int] = {}
                for ev in char_hits:
                    key = skill_key(ev)
                    dmg_by_skill[key] = dmg_by_skill.get(key, 0) + ev.damage
                    cnt_by_skill[key] = cnt_by_skill.get(key, 0) + 1

                char_total = sum(dmg_by_skill.values())
                lines.append(f"  {name}")
                lines.append(f"    {'스킬명':<28} {'딜량':>14} {'히트수':>7} {'비율':>7}")
                lines.append(f"    {'-'*60}")
                for skill, dmg in sorted(dmg_by_skill.items(), key=lambda x: -x[1]):
                    pct = dmg / char_total * 100 if char_total else 0
                    cnt = cnt_by_skill[skill]
                    lines.append(f"    {skill:<28} {dmg:>14,} {cnt:>7} {pct:>6.1f}%")
                lines.append(f"    {'합계':<28} {char_total:>14,}")

        return "\n".join(lines)

    def hit_summary(self, chars: list[str] | None = None) -> str:
        """히트 목록을 시간순으로 출력한다. 재장전·버스트 이벤트를 인터리브한다.

        각 히트 행: 시각 / 캐릭터명 / 스킬명 / 피해량 / 크리·코어 플래그
        인터리브 행: 재장전 시작·완료, 버스트 단계 사용, 풀버스트 시작·종료

        chars 지정 시 해당 캐릭터의 히트만 표시.
        인터리브 이벤트는 chars 필터 적용 대상이지만,
        full_burst 시작/종료(caster 없음)는 항상 출력.
        verbose=False(log=None)이면 인터리브 없이 히트만 출력.
        """
        lines = ["[히트 목록]"]

        # 재장전 + 버스트 이벤트를 하나의 인터리브 목록으로 합산
        inline_events: list[tuple[float, str]] = []
        for e in (self.log.reload_log if self.log else []):
            if not chars or e.caster in chars:
                inline_events.append((e.t, f"{e.caster:<18} [{e.event}]"))
        for e in (self.log.burst_log if self.log else []):
            caster_str = e.caster if e.caster else "스쿼드"
            if not chars or not e.caster or e.caster in chars:
                inline_events.append((e.t, f"{caster_str:<18} [버스트: {e.event}]"))
        inline_events.sort(key=lambda x: x[0])
        inline_idx = 0

        for ev in self.hits:
            while inline_idx < len(inline_events) and inline_events[inline_idx][0] <= ev.t:
                it, msg = inline_events[inline_idx]
                lines.append(f"  t={it:7.3f}s  {msg}")
                inline_idx += 1

            if chars and ev.caster not in chars:
                continue
            flags = ""
            if ev.is_crit:
                flags += " 크리"
            if "core" in ev.hit_tag:
                flags += " 코어"
            lines.append(
                f"  t={ev.t:7.3f}s  {ev.caster:<18} {ev.skill_name:<20}"
                f"  {ev.damage:>12,}{flags}"
            )

        while inline_idx < len(inline_events):
            it, msg = inline_events[inline_idx]
            lines.append(f"  t={it:7.3f}s  {msg}")
            inline_idx += 1

        return "\n".join(lines)


# ── 버스트 구간 분류 분석 ──────────────────────────────────────────────────

@dataclass
class CategoryStat:
    """딜량·히트수 묶음. DamageBreakdown의 각 카테고리를 나타낸다."""
    damage: int = 0
    hits: int = 0

    def pct(self, total: int) -> float:
        """total 대비 이 카테고리의 딜 비율(%)."""
        return self.damage / total * 100 if total else 0.0


@dataclass
class DamageBreakdown:
    """캐릭터 1명의 대미지 분석 결과.

    analyze_damage()가 반환한다. 두 축으로 분류된다:

    피해 유형:
      normal_atk — 기본 발사 루프에서 발생한 피해
      skill      — 스킬 효과(버스트·패시브·DoT 등)에서 발생한 피해

    버스트 구간:
      fb_self  — 본인이 버스트를 사용한 풀버스트 10초 구간
      fb_other — 타인 버스트로 진입한 풀버스트 10초 구간
      non_fb   — 풀버스트 밖 구간

    verbose=False(log=None)로 생성된 SimResult에서는
    버스트 구간 통계(fb_self / fb_other / non_fb)가 모두 0으로 남는다.
    """
    char_name: str

    normal_atk: CategoryStat = field(default_factory=CategoryStat)
    skill: CategoryStat = field(default_factory=CategoryStat)

    fb_self: CategoryStat = field(default_factory=CategoryStat)
    fb_other: CategoryStat = field(default_factory=CategoryStat)
    non_fb: CategoryStat = field(default_factory=CategoryStat)

    _skill_detail: dict[str, CategoryStat] = field(default_factory=dict)
    # 스킬명 → CategoryStat. skill 카테고리의 세부 내역.

    @property
    def total(self) -> int:
        return self.normal_atk.damage + self.skill.damage

    def summary(self) -> str:
        """피해 유형별·버스트 구간별 분석 결과를 출력한다."""
        total = self.total
        fb_total = self.fb_self.damage + self.fb_other.damage + self.non_fb.damage

        lines = [f"=== [{self.char_name}] 대미지 분석 ===", ""]

        lines.append("─ 피해 유형별 비중 ─")
        lines.append(f"  총 대미지  : {total:>15,}")
        lines.append(
            f"  기본 공격  : {self.normal_atk.damage:>15,}  "
            f"({self.normal_atk.pct(total):5.1f}%)  [{self.normal_atk.hits}회]"
        )
        lines.append(
            f"  스킬       : {self.skill.damage:>15,}  "
            f"({self.skill.pct(total):5.1f}%)  [{self.skill.hits}회]"
        )

        if self._skill_detail:
            lines.append("")
            lines.append("  ┌ 스킬 상세")
            for sname, stat in sorted(self._skill_detail.items(), key=lambda x: -x[1].damage):
                lines.append(
                    f"  │  {sname:<30} {stat.damage:>14,}  "
                    f"({stat.pct(total):5.1f}%)  [{stat.hits}회]"
                )
            lines.append("  └")

        lines.append("")
        lines.append("─ 버스트 구간별 비중 ─")
        lines.append(f"  총 대미지      : {fb_total:>15,}")
        lines.append(
            f"  풀버스트 (본인) : {self.fb_self.damage:>15,}  "
            f"({self.fb_self.pct(fb_total):5.1f}%)  [{self.fb_self.hits}회]"
        )
        lines.append(
            f"  풀버스트 (타인) : {self.fb_other.damage:>15,}  "
            f"({self.fb_other.pct(fb_total):5.1f}%)  [{self.fb_other.hits}회]"
        )
        lines.append(
            f"  비풀버스트      : {self.non_fb.damage:>15,}  "
            f"({self.non_fb.pct(fb_total):5.1f}%)  [{self.non_fb.hits}회]"
        )

        return "\n".join(lines)


def analyze_damage(result: SimResult, char_name: str) -> DamageBreakdown:
    """특정 캐릭터의 대미지를 피해 유형별·버스트 구간별로 분석한다.

    버스트 구간 분류는 verbose=True로 생성된 result(result.log 존재) 에서만 동작한다.
    log가 없으면 fb_self / fb_other / non_fb 통계는 모두 0으로 남는다.
    """
    bd = DamageBreakdown(char_name=char_name)

    # burst_log를 순회해 각 풀버스트 구간의 (start, end, is_self) 목록 구성.
    # "stage:N 사용" / "reenter:N 사용" 이벤트의 caster 집합으로
    # 해당 사이클에 본인이 버스트를 사용했는지 판별한다.
    fb_intervals: list[tuple[float, float, bool]] = []

    if result.log is not None:
        pending_casters: set[str] = set()
        fb_start: float | None = None

        for entry in result.log.burst_log:
            if entry.event.endswith("사용"):
                if entry.caster:
                    pending_casters.add(entry.caster)
            elif entry.event == "full_burst 시작":
                fb_start = entry.t
            elif entry.event == "full_burst 종료":
                if fb_start is not None:
                    fb_intervals.append((fb_start, entry.t, char_name in pending_casters))
                fb_start = None
                pending_casters = set()

        # 전투 종료 전 마지막 풀버스트가 닫히지 않은 경우
        if fb_start is not None:
            fb_intervals.append((fb_start, result.duration, char_name in pending_casters))

    def _burst_category(t: float) -> str:
        for start, end, is_self in fb_intervals:
            if start <= t < end:
                return "fb_self" if is_self else "fb_other"
        return "non_fb"

    for ev in result.hits:
        if ev.caster != char_name:
            continue

        burst_stat: CategoryStat = getattr(bd, _burst_category(ev.t))
        burst_stat.damage += ev.damage
        burst_stat.hits += 1

        if _is_normal(ev):
            bd.normal_atk.damage += ev.damage
            bd.normal_atk.hits += 1
        else:
            bd.skill.damage += ev.damage
            bd.skill.hits += 1
            if ev.skill_name not in bd._skill_detail:
                bd._skill_detail[ev.skill_name] = CategoryStat()
            bd._skill_detail[ev.skill_name].damage += ev.damage
            bd._skill_detail[ev.skill_name].hits += 1

    return bd


def analyze_team(result: SimResult) -> list[DamageBreakdown]:
    """스쿼드 전원을 분석해 DamageBreakdown 목록으로 반환한다. 딜량 내림차순 정렬."""
    breakdowns = [analyze_damage(result, name) for name in result.char_total]
    breakdowns.sort(key=lambda b: -b.total)
    return breakdowns


def print_team_analysis(result: SimResult, chars: list[str] | None = None) -> None:
    """스쿼드 전체 분석 결과를 콘솔에 출력한다.

    result.summary() 출력 후 각 캐릭터의 DamageBreakdown.summary()를 출력한다.
    chars 지정 시 해당 캐릭터만 출력.
    """
    print(result.summary(chars))
    print()
    for bd in analyze_team(result):
        if chars and bd.char_name not in chars:
            continue
        print(bd.summary())
        print()
